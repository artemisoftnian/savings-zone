import user from './Login/reducer';
import offerList from './Offers/reducer';
import merchant from './Merchant/reducer';

export default  {
    user,
    offerList,
    merchant
}